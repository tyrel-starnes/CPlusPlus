
/*
Tyrel Starnes
Project 2
10/12/25
*/

#include "INVESTMENU.h"

int main() {
	InvestMenu menu;

	return menu.masterFunc();
}