/* Document contents:
   1. Investment class
   2. InvestMenu class
   */

/*Investment class:
	Purpose:
	1. calulate the end of year interest earned and closing balance 
	   for an investment over a desired span of years.	   

	2. use an Investment object's attributes to display
	   the end of year interest earned and closing balance 
	   for each year.

	************
	* includes *
	************
	
	
	*** setter/getter methods:
	
		** setAttribute(char attribute)
		     -switch case 'attribute' selects attribute, 
		     user input sets value

		** getAttribute(char attribute)
			  -case is 'attribute'. 
			  switch statement returns a value.

	   ************************************************
	   Attribute switch map (set(a-d) and get(a-i))

	   'a' --> p       (principal)
	   'b' --> mDep    (monthly deposit)
	   'c' --> years   (total years)
	   'd' --> intRate (annual interest rate)
	   'e' --> apr     (monthly interest rate)
	   'f' --> mint    (current month interest earned)
	   'g' --> curb    (current balance)
	   'h' --> yeet    (year end interest earned)
	   'i' __> year    (current year counter)
	   ************************************************
	   
    *** Constructors (default sets values to 0)
	
	*** calcData() function
	    - internally handles calculations. snapshots investment
		object and stores in a vector containing investment objects 
		for each year.

    *** displayI() function
	    -uses objects stored in aforementioned vector to output
		a display that shows closing balance and yearly interest
		earned for each year.

   */
#include "INVESTMENT.h"
#include "INVESTMENU.h"

#include <vector>
#include <string>
#include <iomanip>
#include <iostream>
#include <sstream>
using namespace std;




	//Setter switch
    void Investment::setAttribute(char attribute) {
		double userInput;
		int yearInput;

	    switch (attribute) {
	    case 'a':
			cout << "Enter a principle amount (ex. 500.50)" << endl;
			cin >> userInput;
		    p = userInput;
		    break;
	    case 'b':
			cout << "Enter a monthly deposit amount (ex. 50.25)" << endl;
			cin >> userInput;
		    mDep = userInput;
		    break;
	    case 'c':
			cout << "Enter a time in years to invest (ex. 5)" << endl;
			cin >> yearInput;
		    years = yearInput;
		    break;
	    case 'd':
			cout << "Enter annual interest percentage (ex. 2.55)" << endl;
			cin >> userInput;
		    intRate = userInput;
			apr = ((intRate / 100) / 12);  // Recalculate apr
		    break;
	    }
    }

	//Getter switch
	double Investment::getAttribute(char attribute) const {
		switch (attribute) {
		case 'a':
			return p;
		case 'b':
			return mDep;
		case 'c':
			return static_cast<double>(years);
		case 'd':
			return intRate;
		case 'e':
			return apr;
		case 'f':
			return mint;
		case 'g':
			return curb;
		case 'h':
			return yeet;
		case 'i':
			return static_cast<double>(year);
		default:
			return -1.00;
		}

	}


	void Investment::calcData() {		
		int months = years * 12;
		double originalP = p;

		//Calculate with deposits.
		for (int i = 1; i <= months; i++) {			
			p = p + mDep;
			mint = p * apr;
			curb = p + mint;
			p = curb;
			yeet = yeet + mint;

			if (i % 12 == 0) {	
				year = year + 1;
				//snapshot: peer review suggestion
				Investment snapshot(p, mDep, years, intRate);
				snapshot.year = year;
				snapshot.yeet = yeet;
				yearTotals.push_back(snapshot);				
				yeet = 0;
			}			
		}

		//Reset to calulate without deposits.
		mint = 0;
		curb = 0;
		yeet = 0;
		year = 0;
		p = originalP;

		//Calculate without deposits.
		for (int i = 1; i <= months; i++) {			
			mint = p * apr;
			curb = p + mint;
			p = curb;
			yeet = yeet + mint;

			if (i % 12 == 0) {
				year = year + 1;
				//snapshot: peer review suggestion
				Investment snapshot(p, mDep, years, intRate);
				snapshot.year = year;
				snapshot.yeet = yeet;
				nodepTotals.push_back(snapshot);
				yeet = 0;
			}			
		}
		//reset object for any new calculations.
		mint = 0;
		curb = 0;
		yeet = 0;
		year = 0;
		p = originalP;		
	}


	/* InvestMenu Class
	   purpose: Hand Program requirements with a single command
		  1. Provides a master function that runs the entire program with a single command and returns 0.
		  2. Provides a master display function that handles all display output.
		  3. provides option functions to handle user menu selection */
		  

		
		
		
		int InvestMenu::masterFunc() {
			int masterOption = 1;			
			while (masterOption != 2) {
				masterOption = menuInteract();
			}
			cout << "closing program." << endl;
			return 0;
		}

		int InvestMenu::menuInteract() {
			masterDisplay(1);
			int userInput;

			while (true) {
				cin >> userInput;

				switch (userInput) {
				case 0:
					return 2;					
				case 1:
					option1();
					return 1;
					
				case 2:
					option2();
					return 1;
				default:
					cout << "invalid input, try again." << endl;
					return 1;						
				}

				
			}
		}

            /* Processes main menu option 1.
			*  This method prompts users to set multiple Investment
			*  values with one input, or to quit back to the main menu; */
			
		void InvestMenu::option1() {
			string userInput = " ";

			while (userInput != "q") {
				masterDisplay(3);
				cin >> userInput;

				if (userInput == "q") {
				   break;
				}

				for (int i = 0; i < userInput.length(); i++) {
					char c = tolower(userInput[i]);

					if (c == 'a' || c == 'b' || c == 'c' || c == 'd') {
						setAttribute(c);
					}
					else {
						cout << "Invalid character '" << c << "' skipping..." << endl;
					}					
				}	    			
			}
		}

		void InvestMenu::option2() {
			calcData();
			masterDisplay(4);
			masterDisplay(5);
			masterDisplay(2);
		}
		//Prints every screen
		void InvestMenu::masterDisplay(int displaySwitch){
			/*  =================================================
				Display Switch GUide :
				=================================================
				Pass one of the following integers as an argument
				for masterDisplay() to print the desired screen.
				-------------------------------------------------
				1:main menu.
				2:options on the results screen.
				3:data entry Screen.
				4:Results with deposit screen.
				5:Results without deposit screen.
				-------------------------------------------------
				*/
		
		   stringstream sResults;// stream for display with monthly deposit
		   stringstream sNullDep;// stream for display without monthly deposit
		   string mainDisplay;   // main menu
		   string secondMain;    // result screen options
		   string valueDisplay;  // data entry screen
		   string displayWithDep;// display with monthly deposit
		   string displayNoDep;	 // display without monthly deposit

		
			//MAIN MENU DISPLAY
			mainDisplay = "===========================\n"
				"|| Investment Calculator ||\n"
				"===========================\n"
				"|   Select your option    |\n"
				"|-------------------------|\n"
				"| 0. Exit program         |\n"
				"| 1. Enter Investment Data|\n"
				"| 2. Show your investment |\n"
				"===========================\n";
			


			//SECOND SCREEN MAIN OPTIONS;
			secondMain = "********************************** \n"
				         "** press '0' to quit program.   ** \n"
				         "** pres '1' to edit values.     ** \n"
				         "** (return to data entry screen)** \n"
				         "********************************** \n";


			//DATA ENTRY SCREEN
			valueDisplay = "Enter which values to set or 'q' to quit \n"
				           "========================================= \n"
				           "**************NO SPACES******************\n"
				           "Example: 'abcd' or 'acd'\n"
				           "-----------------------------------------\n"
				           " 'a' : Enter principle amount. \n"
				           " 'b' : Enter monthly deposit. \n"
				           " 'c' : Enter annual interest rate. \n"
				           " 'd' : Enter the total investment years. \n"
			               "-----------------------------------------\n";



			//RESULTS WITH MONTHLY DEPOSIT
			// header
			sResults << setfill(' ') << left << setw(50)
				<< "   Balance and Interest with Monthly Deposit" << endl;
			sResults << setfill('=') << setw(50) << "" << endl;

			// column header
			sResults << left << setw(8) << "Year"
				<< setw(24) << "Year End Balance"
				<< setw(18) << right << "Year End Interest" << endl;
			sResults << setfill('-') << setw(50) << "" << endl;


			//data row
			for (int i = 0; i < yearTotals.size(); i++) {
				sResults << setfill(' ') << left << setw(13) << yearTotals[i].year
					<< setfill(' ') << left << setw(19) << fixed << setprecision(2) << yearTotals[i].p
					<< setfill(' ') << right << setw(18) << fixed << setprecision(2) << yearTotals[i].yeet
					<< endl;
			}
			


			//RESULTS ***WITHOUT*** MONTHLY DEPOSIT
			sNullDep << setfill(' ') << left << setw(50)
				<< "   Balance and Interest without Monthly Deposit" << endl;
			sNullDep << setfill('=') << setw(50) << "" << endl;

			// column header
			sNullDep << left << setw(8) << "Year"
				<< setw(24) << "Year End Balance"
				<< setw(18) << right << "Year End Interest" << endl;
			sNullDep << setfill('-') << setw(50) << "" << endl;

			//data row
			for (int i = 0; i < nodepTotals.size(); i++) {
				sNullDep << setfill(' ') << left << setw(13) << nodepTotals[i].year
					<< setfill(' ') << left << setw(19) << fixed << setprecision(2) << nodepTotals[i].p
					<< setfill(' ') << right << setw(18) << fixed << setprecision(2) << nodepTotals[i].yeet
					<< endl;
			}			

			switch (displaySwitch) {
			case 1: // main display
				cout << mainDisplay << endl;
				break;
			case 2: // for results screen
				cout << secondMain << endl;
				break;
			case 3: // for data entry
				cout << valueDisplay << endl;
				break;
			case 4: // display with deposit
				displayWithDep = sResults.str();
				cout << displayWithDep << endl;
				break;
			case 5: // display without deposit
				displayNoDep = sNullDep.str(); //builds only as needed
				cout << displayNoDep << endl;
				break;
			default:
				cout << "invalid display switch option" << endl;
				break;
			}
		
	    }

		
			
		



			
		



