#ifndef INVESTMENU_H
#define INVESTMENU_H

#include "INVESTMENT.h"

class InvestMenu : public Investment {

public:

	//METHODS*******************************
	int masterFunc(); // A single function that handles the program and returns 0.


private:

	//METHODS*******************************
	int menuInteract(); // Processes main menu options from user input.		
	void option1();      // sets values values from input.
	void option2();      // displays final calulcation.			                
	void masterDisplay(int displaySwitch);// handles all output displays.

};

#endif