#ifndef INVESTMENT_H
#define INVESTMENT_H

#include <vector>
#include <string>

class Investment {

public:
	//ATTRIBUTES****************************
	double p;         //principal
	double mDep = 0; // monthly deposit default set to 0
	int years;       // total years of investment.	
	double intRate;  // annual interest rate

	//METHODS*******************************

	void setAttribute(char attribute);
	double getAttribute(char attribute) const;


	//default constructor
	Investment() //constructor initializer list (codeacademy)
		: p(0.00), mDep(0.00),
		years(0), intRate(0.00),
		apr(((intRate / 100) / 12)),
		mint(0.00), curb(0.00),
		yeet(0.00), year(0) {
	}


	//calcData input constructor
	Investment(double t_p, double t_mDep,
		int t_years, double t_intRate)
		: p(t_p), mDep(t_mDep),
		years(t_years), intRate(t_intRate),
		apr(((intRate / 100) / 12)),
		mint(0.00), curb(0.00),
		yeet(0.00), year(0) {
	}


protected:
	//ATTRIBUTES****************************
	std::vector <Investment> yearTotals; //vector of Investment objects
	std::vector <Investment> nodepTotals;// same without deposit
	double yeet; // year end earned interest
	int year;    // counter variable for calcData() 


	//METHODS*******************************
	void calcData();//calculates end of year totals for each year
	//then stows a snapshot of the class in a vector.


private:
	//ATTRIBUTES****************************
	double apr;  // monthly interest rate	
	double mint; // current month earned interest
	double curb; // current month end balance


};

#endif
